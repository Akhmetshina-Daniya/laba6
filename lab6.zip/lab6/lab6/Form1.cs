﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace lab6
{
    public partial class Form1 : Form
    {
        public int width;
        public int height;
        public int d;
        public int a;
        public int corx;
        public int cory;
        public RECT rc = new RECT();
        public IntPtr winn;

        delegate bool EnumWindowsProc(IntPtr winn, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true)]
        static extern int GetWindowText(IntPtr winn, StringBuilder lpString, int nMaxCount);
        string GetWindowText(IntPtr winn)
        {
            int len = GetWindowTextLength(winn) + 1;
            StringBuilder sb = new StringBuilder(len);
            len = GetWindowText(winn, sb, len);
            return sb.ToString(0, len);
        }

        [DllImport("user32.dll", SetLastError = true)]
        static extern int GetWindowTextLength(IntPtr winn);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool IsWindowVisible(IntPtr winn);

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll", SetLastError = true)]
        static extern int SetWindowText(IntPtr winn, string text);

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool GetWindowRect(IntPtr winn, ref RECT lpRect);
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }
        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr SetWindowPos(IntPtr winn, IntPtr hWndInsertAfter, int D, int A, int cd, int ca, uint uFlags);
        [DllImport("user32.dll", SetLastError = true)]
        static extern bool GetCursorPos(out POINT lpPoint);
        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int D;
            public int A;
        }
        public static POINT GetCursorPosition()
        {
            POINT lpPoint;
            GetCursorPos(out lpPoint);
            return lpPoint;
        }

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool MoveWindow(IntPtr winn, int D, int A, int Width, int Height, bool Repaint);


        public Form1()
        {
            InitializeComponent();
        }

        System.Timers.Timer timer1;

        public delegate void InvokeDelegate();
        public string selitem;

        private void filler()
        {
            Лист.Items.Clear();
            EnumWindows((winn, lParam) =>
            {
                if (IsWindowVisible(winn) && GetWindowTextLength(winn) != 0)
                {
                    Лист.Items.Add(GetWindowText(winn));
                }
                return true;
            }, IntPtr.Zero);
        }

        private void EventFill(object sender, EventArgs e)
        {
            Лист.BeginInvoke(new InvokeDelegate(filler));
        }

        private void EventText(object sender, EventArgs e)
        {
            SetWindowText(winn, textBox1.Text);
            selitem = GetWindowText(winn);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Size resolution = Screen.PrimaryScreen.Bounds.Size;


            timer1 = new System.Timers.Timer();

            Лист.Items.Clear();

            timer1.Interval = 1000;

            timer1.Elapsed += EventFill;
            timer1.Elapsed += EventText;

            timer1.Start();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (Лист.SelectedIndex != -1)
            {

                winn = FindWindow(null, Лист.SelectedItem.ToString());

                GetWindowRect(winn, ref rc);

                width = rc.Right - rc.Left;
                height = rc.Bottom - rc.Top;
                d = rc.Left;
                a = rc.Top;

                textBox1.Text = GetWindowText(winn);
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            try
            {
                corx = System.Convert.ToInt32(textBox3.Text);
            }
            catch (Exception ex){ }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                cory = System.Convert.ToInt32(textBox2.Text);
            }
            catch (Exception ex){ }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MoveWindow(winn, corx, cory, width, height, true);

            GetWindowRect(winn, ref rc);

            d = rc.Left;
            a = rc.Top;
        }

        private void hScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            int height2 = height * hScrollBar1.Value;
            int width2 = width * hScrollBar1.Value;
            MoveWindow(winn, d, a, width2, height2, true);
            MessageBox.Show(hScrollBar1.Value.ToString());
        }
    }
}